<?php
include 'uheader.php';


?>



      <div class="content-wrapper  js-content-wrapper">
        <aside class="sidebar js-sidebar">
          <div class="sidebar__cross">
            <button class="button js-sidebar-close">
              <i class="icon icon-cross"></i>
            </button>
          </div>

          <div class="sidebar__header">
            <div class="sidebar__logo">
              <img src="img/general/logo-light.svg" alt="helix logo">
            </div>

            <h4 class="title">HELLIX</h4>
            <p class="subtitle">AN-AWARD WINNING ARCHITECTURE COMPANY</p>
          </div>

          <div class="sidebar__instagram">
            <h5 class="title">#hellix</h5>

            <div class="instagram">

              <a data-barba href="#" class="instagram__item">
                <div class="instagram__image">
                  <div class="ratio ratio-1:1 bg-image js-lazy" data-bg="img/main-sidebar/instagram/1.jpg"></div>
                </div>

                <div class="instagram__content">
                  <i class="icon fa fa-instagram" aria-hidden="true"></i>
                </div>
              </a>

              <a data-barba href="#" class="instagram__item">
                <div class="instagram__image">
                  <div class="ratio ratio-1:1 bg-image js-lazy" data-bg="img/main-sidebar/instagram/2.jpg"></div>
                </div>

                <div class="instagram__content">
                  <i class="icon fa fa-instagram" aria-hidden="true"></i>
                </div>
              </a>

              <a data-barba href="#" class="instagram__item">
                <div class="instagram__image">
                  <div class="ratio ratio-1:1 bg-image js-lazy" data-bg="img/main-sidebar/instagram/3.jpg"></div>
                </div>

                <div class="instagram__content">
                  <i class="icon fa fa-instagram" aria-hidden="true"></i>
                </div>
              </a>

              <a data-barba href="#" class="instagram__item">
                <div class="instagram__image">
                  <div class="ratio ratio-1:1 bg-image js-lazy" data-bg="img/main-sidebar/instagram/4.jpg"></div>
                </div>

                <div class="instagram__content">
                  <i class="icon fa fa-instagram" aria-hidden="true"></i>
                </div>
              </a>

              <a data-barba href="#" class="instagram__item">
                <div class="instagram__image">
                  <div class="ratio ratio-1:1 bg-image js-lazy" data-bg="img/main-sidebar/instagram/5.jpg"></div>
                </div>

                <div class="instagram__content">
                  <i class="icon fa fa-instagram" aria-hidden="true"></i>
                </div>
              </a>

              <a data-barba href="#" class="instagram__item">
                <div class="instagram__image">
                  <div class="ratio ratio-1:1 bg-image js-lazy" data-bg="img/main-sidebar/instagram/6.jpg"></div>
                </div>

                <div class="instagram__content">
                  <i class="icon fa fa-instagram" aria-hidden="true"></i>
                </div>
              </a>

            </div>
          </div>

          <div class="sidebar__info">
            <h5 class="title">Let's Start a Project</h5>
            <p class="text">
              T: +1 333 436 1747<br>
              M: hi@hellix.com
            </p>
            <p class="text">
              A: PO Box 16122 Collins Street West<br>
              Victoria 8007 Australia
            </p>

            <button class="button -simple">GET DIRECTIONS</button>
          </div>

          <div class="sidebar__socials">
            <div class="item">
              <a data-barba href="#">
                <i class="fa fa-facebook" aria-hidden="true"></i>
              </a>
            </div>
            <div class="item">
              <a data-barba href="#">
                <i class="fa fa-twitter" aria-hidden="true"></i>
              </a>
            </div>
            <div class="item">
              <a data-barba href="#">
                <i class="fa fa-instagram" aria-hidden="true"></i>
              </a>
            </div>
            <div class="item">
              <a data-barba href="#">
                <i class="fa fa-linkedin" aria-hidden="true"></i>
              </a>
            </div>
          </div>
        </aside>


        <section class="page-masthead">
          <div data-parallax="0.6" class="page-masthead__bg">
            <div data-parallax-target class="bg-image js-lazy" data-bg="img/backgrounds/13.jpg"></div>
          </div>

          <div class="container">
            <div class="page-masthead__content">
              <div class="row justify-content-between md:justify-content-center align-items-center">
                <div class="col-lg-9 col-md-10">
                  <div data-anim="slide-up delay-1">
                    <div class="page-masthead__subtitle">PRODUCTS</div>
                    <div class="page-masthead__back_title">Shop Checkout</div>
                    <h1 class="page-masthead__title text-white">Shop Checkout</h1>
                  </div>
                </div>

                <div class="col-auto">
                  <div data-anim="slide-up delay-1" class="page-masthead-bread text-white md:mt-24">
                    <a data-barba href="index.html" class="page-masthead-bread__item">Home</a>
                    /
                    <a data-barba href="#" class="page-masthead-bread__item ">Shop Checkout</a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>


        <section class="layout-pt-md layout-pb-md">
          <div class="container">
            <div class="row x-gap-60">
              <div class="col-lg">
                <div class="shopCheckout-form">
                  <form action="https://creativelayers.net/themes/hellix-html/post" class="row x-gap-24 y-gap-40">
                    <div class="col-12">
                      <h4 class="shopCheckout-form__title">Billing Details</h4>
                    </div>
                    <div class="col-sm-6">
                      <input type="text" name="firstName" placeholder="First name">
                    </div>

                    <div class="col-sm-6">
                      <input type="text" name="lastName" placeholder="Last name">
                    </div>

                    <div class="col-12">
                      <input type="text" name="company" placeholder="Company">
                    </div>

                    <div class="col-12">
                      <select class="selectize wide js-selectize">
                        <option data-display="Select">Country</option>
                        <option value="Greece">Greece</option>
                        <option value="USA">USA</option>
                        <option value="Germany">Germany</option>
                        <option value="France">France</option>
                      </select>
                    </div>

                    <div class="col-12">
                      <input type="text" name="address" placeholder="Street Address">
                    </div>

                    <div class="col-sm-6">
                      <input type="text" name="postcode" placeholder="Postcode / ZIP">
                    </div>

                    <div class="col-sm-6">
                      <input type="text" name="city" placeholder="Town / City">
                    </div>

                    <div class="col-sm-6">
                      <input type="text" name="province" placeholder="Province">
                    </div>

                    <div class="col-sm-6">
                      <input type="text" name="phone" placeholder="Phone">
                    </div>

                    <div class="col-12">
                      <input type="email" name="email" placeholder="YourEmail">
                    </div>

                    <div class="col-12">
                      <h4 class="shopCheckout-form__title pb-16">Additional information</h4>
                    </div>
                    <div class="col-12">
                      <textarea name="notes" id="form_notes" rows="4" placeholder="Order notes (optional)"></textarea>
                    </div>
                  </form>
                </div>
              </div>

              <div class="col-lg-auto">
                <div class="shopCart-sidebar">
                  <div class="shopCart-sidebar__totals">
                    <h5 class="title">
                      YOUR ORDER
                    </h5>

                    <div class="item">
                      <span class="fw-600 text-black">Product</span>
                      <span class="fw-600 text-black">Subtotal</span>
                    </div>

                    <div class="item">
                      <span class="text-grey">Hoodie x2</span>
                      <span class="text-grey">$59.00</span>
                    </div>

                    <div class="item -border-none">
                      <span class="text-grey">Seo Books x 1</span>
                      <span class="text-grey">$67.00</span>
                    </div>

                    <div class="item -border-none">
                      <span class="fw-600 text-black">Subtotal</span>
                      <span class="fw-600 text-black">$178.00</span>
                    </div>

                    <div class="item">
                      <span class="fw-600 text-black">Shipping</span>
                      <span class="fw-600 text-black">$178.00</span>
                    </div>

                    <div class="item">
                      <span class="fw-600 text-black">Total</span>
                      <span class="fw-600 text-black">$9,218.00</span>
                    </div>
                  </div>

                  <div class="shopCart-sidebar__button">
                    <button class="button -md -accent col-12 text-white">PROCEED TO CHECKOUT</button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>


        <?php
include 'footer.php';


?>
