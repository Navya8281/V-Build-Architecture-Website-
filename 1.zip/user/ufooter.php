 <footer class="footer -type-1">

          <div class="footer__top">
            <div class="container">
              <div class="row y-gap-48 justify-content-between">

                <div class="col-lg-3 col-md-6">
                  <div class="footer__item">
                    <h3 class="footer__title text-white">Contact</h3>

                    <div class="footer__content pr-20">
                      <div class="footer__content__item">
                        <p><span>T:</span> +1 333 436 1747</p>
                        <p><span>M:</span> hi@hellix.com</p>
                      </div>

                      <div class="footer__content__item">
                        <p><span>A:</span> PO Box 16122 Collins Street West Victoria 8007 Australia</p>
                      </div>

                      <div class="footer__content__item">
                        <a data-barba href="#" class="button -simple text-white">GET DIRECTIONS</a>
                      </div>
                    </div>
                  </div>
                </div>


                <div class="col-lg-3 col-md-6">
                  <div class="footer__item">
                    <h3 class="footer__title text-white">OUR SERVICES</h3>

                    <div class="footer__content">
                      <div class="footer__content__item">
                        <a data-barba href="#">Architecture & Interior</a>
                      </div>

                      <div class="footer__content__item">
                        <a data-barba href="#">Project Planning</a>
                      </div>

                      <div class="footer__content__item">
                        <a data-barba href="#">Product Design</a>
                      </div>

                      <div class="footer__content__item">
                        <a data-barba href="#">Custom Solutions</a>
                      </div>
                    </div>
                  </div>
                </div>


                <div class="col-lg-3 col-md-6">
                  <div class="footer__item">
                    <h3 class="footer__title text-white">USEFUL LINKS</h3>

                    <div class="footer__content">
                      <div class="footer__content__item">
                        <a data-barba href="#">Project</a>
                      </div>

                      <div class="footer__content__item">
                        <a data-barba href="#">News</a>
                      </div>

                      <div class="footer__content__item">
                        <a data-barba href="#">About</a>
                      </div>

                      <div class="footer__content__item">
                        <a data-barba href="#">Contact Us</a>
                      </div>

                      <div class="footer__content__item">
                        <a data-barba href="#">Shop</a>
                      </div>

                      <div class="footer__content__item">
                        <a data-barba href="#">FAQ</a>
                      </div>

                      <div class="footer__content__item">
                        <a data-barba href="#">Privacy Policy</a>
                      </div>
                    </div>
                  </div>
                </div>


                <div class="col-lg-3 col-md-6">
                  <div class="footer__item">
                    <h3 class="footer__title text-white">SUBSCRIBE</h3>

                    <div class="footer__content">
                      <div class="footer__content__item">
                        <p>We will send you updates on new products and discounts.</p>
                      </div>

                      <div class="footer__newsletter">
                        <form action="https://creativelayers.net/themes/hellix-html/POST">
                          <input placeholder="Your Email" type="email">

                          <button type="submit">
                            <i class="icon icon-send"></i>
                          </button>
                        </form>
                      </div>

                      <div class="footer__socials">
                        <h3 class="footer__title text-white">FOLLOW US</h3>

                        <div class="footer__socials_content">
                          <a data-barba href="#" class="text-white">
                            <i class="fa fa-facebook" aria-hidden="true"></i>
                          </a>
                          <a data-barba href="#" class="text-white">
                            <i class="fa fa-twitter" aria-hidden="true"></i>
                          </a>
                          <a data-barba href="#" class="text-white">
                            <i class="fa fa-instagram" aria-hidden="true"></i>
                          </a>
                          <a data-barba href="#" class="text-white">
                            <i class="fa fa-linkedin" aria-hidden="true"></i>
                          </a>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

              </div>
            </div>
          </div>


          <div class="footer__bottom">
            <div class="container">
              <div class="row align-items-center justify-content-between sm:justify-content-start">
                <div class="col-auto sm:order-2">
                  <div class="footer__bottom_text">© 2021 Hellix. All rights reserved.</div>
                </div>

                <div class="col-auto sm:order-1">
                  <div class="footer__logo">
                    <img src="img/general/logo.svg" alt="logo">
                  </div>
                </div>

                <div class="col-auto sm:d-none">
                  <div class="footer__bottom_text">Designed by CreativeLayers</div>
                </div>
              </div>
            </div>
          </div>


          <div data-cursor class="backButton js-backButton">
            <div class="nav -slider">
              <div class="nav__item -left">
                <i class="icon icon-right-arrow"></i>
              </div>
            </div>
          </div>

        </footer>


      </div>
    </main>
  </div>
  <!-- barba container end -->


  <!-- JavaScript -->
  <script src="dist/leaflet.js" ></script>
  <script src="js/vendors.js"></script>
  <script src="js/main.js"></script>

</body>


<!-- Mirrored from creativelayers.net/themes/hellix-html/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 06 Oct 2022 11:13:40 GMT -->
</html>