<?php
include('../database.php');
 $id=$_POST['id'];
 $fname=$_POST['fname'];
$lname=$_POST['lname'];
 $address=$_POST['address'];
 $email=$_POST['email'];
 $password=$_POST['password'];
 $mobilenumber=$_POST['phonenumber'];
$status=$_POST['status'];


  $sql="UPDATE `real_estate_registration` SET `r_fname`='$fname',`r_lname`='$lname',`r_address`='$address',`r_email`='$email',`r_password`='$password',`r_mobilenumber`='$mobilenumber' WHERE rl_id=$id";
$result=mysqli_query($con,$sql);
 $sql1="UPDATE `login` SET `l_approve`='$status' WHERE l_id=$id";
$results=mysqli_query($con,$sql1);


if($result==1)
{
   // echo "success";
   header("location:realestateprofile.php");
}
else
{
 echo "failed";
}

?>